<html>
    <body>
        <form action="submit"></form>
    </body>
</html>