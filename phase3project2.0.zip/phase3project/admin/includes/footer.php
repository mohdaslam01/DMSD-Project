<footer>
            <div class="footer-area">
                <p>Turtle Zoo Management System </p>
            </div>
        </footer>